

Exercício - Nessa atividade você usará classes já criadas para ler um arquivo no formato csv. Esse arquivo contém informações dos clientes: id;cliente;email;data_nascimento;telefone;total_compras. Você carregará essas informações e para cada linha criará um objeto cliente. 
<br>


1) Utilize o LeCsv.java para ler o arquivo.csv. Com esses dados crie objetos da classe Cliente. Você precisa completar o código na classe LeCsv.java para que ele faça o split das informações do arquivo csv através do ";" <br>
  //complete o codigo para da classe LeCsv.java para ler o csv e criar as instancias de cliente.<br><br>

2)Para testar o projeto rode o arquivo de teste MainReadCsvTest.java. Esse código já está criado<br>
ele utiliza a seguinte linha para recuperar as informações de clientes: LinkedList<Cliente> clientes = leitorCsv.leCsvClientes(); // cria a lista de clientes. A soma total deve ser 25.000


