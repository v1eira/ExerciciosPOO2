
Exercício -  Fábrica Abstrata  - Modelo de classe telefonia. 

Altere o código do projeto para adicionar a Operadora Claro que falta no modelo. 
O código do exemplo está no pacote fabrica.abstrata

Abaixo o modelo do projeto com as respectivas classes que faltam.

![alt text](https://github.com/felipefo/poo2/blob/master/Padroes_de_Projeto/Criação/fabrica_abstrata/FabricaAbstrataTelefonia/diagrama_classe.png)



